<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        @vite(['resources/scss/app.scss', 'resources/js/app.js'])
    </head>
    <body>

        <x-layouts.applyloan>
            <form class="education-form" action="{{ route('loan-form3submit') }}" method="POST">
                @csrf
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    ยอมรับข้อตกลงและเงื่อนไข <br class="block md:hidden" />
                    และการให้ความยินยอม
                </h1>
                <div class="bg-[#ef3026]/20 p-4 rounded-lg">
                    <div class="p-2 bg-[#ef3026]/50 text-black text-center rounded-lg mb-2">
                        <div class="inline-flex items-center">
                            <input type="checkbox" class="shrink-0 mt-0.5 border-red-200 rounded text-red-600 focus:ring-red-500" id="select-all">
                            <label for="select-all" class="text-bold font-medium ml-3">ยอมรับทั้งหมด</label>
                        </div>
                    </div>

                    <div class="p-2 bg-[#E0C9C9]/50 text-black rounded-lg mb-2">
                        <p class="text-black font-bold">
                            เพื่อการใช้บริการและแอปพลิเคชั่นของบริษัท สบายใจมันนี่ จำกัด
                        </p>
                        <p>
                            คุณรับทราบและยอมรับข้อกำหนดและเงื่อนไขในการใช้บริการ และแอปพลิเคชั่นของบริษัท สบายใจมันนี่ จำกัด (“T&C”)
                        </p>
                        <div class="flex gap-7 mt-2">
                            <div class="inline-flex">
                                <input type="radio" name="tc_1" class="shrink-0 mt-0.5 border-gray-200 rounded-full text-red-600 focus:ring-red-500" id="accept-1" @if(isset($data['tc_1']) && $data['tc_1'] == 'on') checked @endif>
                                <label for="accept-1" class="text-bold font-medium ml-2">ยอมรับ</label>
                            </div>
                        </div>
                    </div>

                    <div class="p-2 bg-[#E0C9C9]/50 text-black rounded-lg mb-2">
                        <p class="text-black font-bold">
                            เพื่อรับข่าวสารการตลาด ข้อเสนอพิเศษ
                        </p>
                        <p>
                            คุณยินยอมให้บริษัทเก็บรวบรวมและใช้ข้อมูลส่วนบุคคล เพื่อการวิจัย วิเคราะห์ข้อมูล พัฒนา และเสนอผลิตภัณฑ์ บริการ และสิทธิประโยชน์ที่เหมาะสมแก่คุณ
                        </p>
                        <div class="flex gap-7 mt-2">
                            <div class="inline-flex">
                                <input type="radio" name="tc_2" class="shrink-0 mt-0.5 border-gray-200 rounded-full text-red-600 focus:ring-red-500" id="accept-2" @if(isset($data['tc_2']) && $data['tc_2'] == 'on') checked @endif>
                                <label for="accept-2" class="text-bold font-medium ml-2">ยอมรับ</label>
                            </div>
                            <div class="inline-flex">
                                <input type="radio" name="tc_2" class="shrink-0 mt-0.5 border-gray-200 rounded-full text-red-600 focus:ring-red-500" id="deny-2" @if(isset($data['tc_2']) && $data['tc_2'] == 'off') checked @endif>
                                <label for="deny-2" class="text-bold font-medium ml-2">ปฏิเสธ</label>
                            </div>
                        </div>
                    </div>

                    <div class="p-2 bg-[#E0C9C9]/50 text-black rounded-lg mb-2">
                        <p class="text-black font-bold">
                            เพื่อรับข่าวสารการตลาดจากบริษัทในกลุ่มธุรกิจสบายใจมันนี่ และพันธมิตรทางธุรกิจที่เชื่อถือได้ของบริษัท
                        </p>
                        <p>
                            คุณยินยอมให้บริษัทเปิดเผยข้อมูลส่วนบุคคล และข้อมูลใดๆ ให้แก่บริษัทในกลุ่มธุรกิจสบายใจมันนี่และพันธมิตรทางธุรกิจที่เชื่อถือได้
                            ของบริษัท เพื่อการวิจัย วิเคราะห์ข้อมูล พัฒนา และเสนอผลิตภัณฑ์ บริการและสิทธิประโยชน์ที่เหมาะสมแก่คุณ(ความยินยอมไม่มีผลต่อการพิจารณา)
                        </p>
                        <div class="flex gap-7 mt-2">
                            <div class="inline-flex">
                                <input type="radio" name="tc_3" class="shrink-0 mt-0.5 border-gray-200 rounded-full text-red-600 focus:ring-red-500" id="accept-3" @if(isset($data['tc_3']) && $data['tc_3'] == 'on') checked @endif>
                                <label for="accept-3" class="text-bold font-medium ml-2">ยอมรับ</label>
                            </div>
                            <div class="inline-flex">
                                <input type="radio" name="tc_3" class="shrink-0 mt-0.5 border-gray-200 rounded-full text-red-600 focus:ring-red-500" id="deny-3" @if(isset($data['tc_3']) && $data['tc_3'] == 'off') checked @endif>
                                <label for="deny-3" class="text-bold font-medium ml-2">ปฏิเสธ</label>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="flex justify-center items-center gap-5">
                <a href="{{ route('loan-form2') }}" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
            </div>
            </form
        </x-layouts.applyloan>
        <script src="{{ asset('js/preline.js') }}"></script>
    </body>
</html>
