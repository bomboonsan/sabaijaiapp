<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body class="">

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="text-center">
                <div class="educationIcon">
                    <img src="<?php echo e(asset('images/educationIcon.png')); ?>" alt="educationIcon" />
                    <p class="text-center">
                        สินเชื่อ<br/>
                        เพื่อการศึกษา
                    </p>
                </div>
                <div class="mt-10">
                    <a href="<?php echo e(route('loan-form1')); ?>" class="educationBtn">แก้ไข หรือ กรอกใบสมัครต่อ</a>
                </div>
                <div class="mt-5">
                    <a href="<?php echo e(route('loan-form1')); ?>" class="educationBtn">แนบเอกสารเพิ่มเติม</a>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/index.blade.php ENDPATH**/ ?>