<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    กรอกรายได้และค่าใช้จ่าย
                </h1>
                <form class="education-form" action="<?php echo e(route('loan-form5submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label htmlFor="main_occupation">อาชีพหลัก</label>
                        <select id="main_occupation" class="w-full" name="main_occupation">
                            <option value="1" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '1'): ?> selected <?php endif; ?>>เจ้าของธุรกิจที่มีลูกจ้าง</option>
                            <option value="2" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '2'): ?> selected <?php endif; ?>>เจ้าของธุรกิจที่ไม่มีลูกจ้าง หรือ อาชีพอิสระ</option>
                            <option value="3" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '3'): ?> selected <?php endif; ?>>รวมกลุ่มกันเพื่อผลิตสินค้า/บริการ</option>
                            <option value="4" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '4'): ?> selected <?php endif; ?>>ผู้ช่วยธุรกิจในครัวเรือน (ไม่ได้รับค่าจ้าง)</option>
                            <option value="5" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '5'): ?> selected <?php endif; ?>>ข้าราชการบำนาญ</option>
                            <option value="6" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '6'): ?> selected <?php endif; ?>>นักการเมือง</option>
                            <option value="7" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '7'): ?> selected <?php endif; ?>>อัยการ/ตุลาการ/ผู้พิพากษา</option>
                            <option value="8" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '8'): ?> selected <?php endif; ?>>นักกฎหมายและผู้ใช้วิชาชีพทางกฎหมาย</option>
                            <option value="9" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '9'): ?> selected <?php endif; ?>>ทหาร/ตำรวจ</option>
                            <option value="10" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '10'): ?> selected <?php endif; ?>>ครู อาจารย์ และผู้ประกอบอาชีพการศึกษา (ยกเว้นติวเตอร์)</option>
                            <option value="11" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '11'): ?> selected <?php endif; ?>>แพทย์</option>
                            <option value="12" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '12'): ?> selected <?php endif; ?>>พยาบาล และผู้ประกอบการอาชีพที่เกี่ยวกับการแพทย์</option>
                            <option value="13" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '13'): ?> selected <?php endif; ?>>ข้าราชการอื่นๆ (ที่ไม่ใช่ข้อก่อนหน้า)</option>
                            <option value="14" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '14'): ?> selected <?php endif; ?>>วิศวกร/สถาปนิก</option>
                            <option value="15" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '15'): ?> selected <?php endif; ?>>นักบิน/ผู้ช่วยนักบิน/แอร์โฮสเตส/สจ๊วต</option>
                            <option value="16" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '16'): ?> selected <?php endif; ?>>พนักงานประจำ , พนักงานรัฐวิสาหกิจ</option>
                            <option value="17" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '17'): ?> selected <?php endif; ?>>ลูกจ้างชั่วคราว , พนักงานสัญญาจ้าง</option>
                            <option value="18" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '18'): ?> selected <?php endif; ?>>บุคคลในวงการบันเทิง</option>
                            <option value="19" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '19'): ?> selected <?php endif; ?>>บุคคลในวงการกีฬา</option>
                            <option value="20" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '20'): ?> selected <?php endif; ?>>ผู้เกษียณที่ไม่ได้รับบำนาญ</option>
                            <option value="21" <?php if(isset($data['main_occupation']) && $data['main_occupation'] == '21'): ?> selected <?php endif; ?>>อื่นๆ </option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="nature_employment">ลักษณะการจ้างงาน</label>
                        <select id="nature_employment" class="w-full" name="nature_employment">
                            <option value="1" <?php if(isset($data['nature_employment']) && $data['nature_employment'] == '1'): ?> selected <?php endif; ?>>ข้าราชการ</option>
                            <option value="2" <?php if(isset($data['nature_employment']) && $data['nature_employment'] == '2'): ?> selected <?php endif; ?>>งานส่วนตัว นายจ้าง</option>
                            <option value="3" <?php if(isset($data['nature_employment']) && $data['nature_employment'] == '3'): ?> selected <?php endif; ?>>ผู้มีงานทำอื่นๆ</option>
                            <option value="4" <?php if(isset($data['nature_employment']) && $data['nature_employment'] == '4'): ?> selected <?php endif; ?>>ผู้เกษียณที่ไม่ได้รับบำนาญ</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="type_business">ประเภทธุรกิจขององค์กรหรือหน่วยงานที่ทำงานอยู่</label>
                        <select id="type_business" class="w-full" name="type_business">
                            <option value="เกษตร" <?php if(isset($data['type_business']) && $data['type_business'] == 'เกษตร'): ?> selected <?php endif; ?>>เกษตร</option>
                            <option value="อุตสาหกรรมการผลิต" <?php if(isset($data['type_business']) && $data['type_business'] == 'อุตสาหกรรมการผลิต'): ?> selected <?php endif; ?>>อุตสาหกรรมการผลิต</option>
                            <option value="ก่อสร้าง" <?php if(isset($data['type_business']) && $data['type_business'] == 'ก่อสร้าง'): ?> selected <?php endif; ?>>ก่อสร้าง</option>
                            <option value="การค้า" <?php if(isset($data['type_business']) && $data['type_business'] == 'การค้า'): ?> selected <?php endif; ?>>การค้า</option>
                            <option value="บริการที่เกี่ยวกับการท่องเที่ยว" <?php if(isset($data['type_business']) && $data['type_business'] == 'บริการที่เกี่ยวกับการท่องเที่ยว'): ?> selected <?php endif; ?>>บริการที่เกี่ยวกับการท่องเที่ยว</option>
                            <option value="บริการทางการเงิน" <?php if(isset($data['type_business']) && $data['type_business'] == 'บริการทางการเงิน'): ?> selected <?php endif; ?>>บริการทางการเงิน</option>
                            <option value="บริการอสังหาริมทรัพย์" <?php if(isset($data['type_business']) && $data['type_business'] == 'บริการอสังหาริมทรัพย์'): ?> selected <?php endif; ?>>บริการอสังหาริมทรัพย์</option>
                            <option value="บริการอื่นๆ" <?php if(isset($data['type_business']) && $data['type_business'] == 'บริการอื่นๆ'): ?> selected <?php endif; ?>>บริการอื่นๆ</option>
                            <option value="องค์กรไม่แสวงหากำไร" <?php if(isset($data['type_business']) && $data['type_business'] == 'องค์กรไม่แสวงหากำไร'): ?> selected <?php endif; ?>>องค์กรไม่แสวงหากำไร</option>
                            <option value="การบริหารราชการ" <?php if(isset($data['type_business']) && $data['type_business'] == 'การบริหารราชการ'): ?> selected <?php endif; ?>>การบริหารราชการ</option>
                            <option value="อื่นๆ" <?php if(isset($data['type_business']) && $data['type_business'] == 'อื่นๆ'): ?> selected <?php endif; ?>>อื่นๆ</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="main_income_per_month">รายได้หลักรวมต่อเดือน</label>
                        <div id="main_income_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="main_income_per_month" value="<?php echo e(isset($data['main_income_per_month']) ? $data['main_income_per_month'] : ''); ?>" />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="additional_career">อาชีพเสริม (ถ้ามี)</label>
                        <select id="additional_career" class="w-full" name="additional_career">
                            <option value="1" <?php if(isset($data['additional_career']) && $data['additional_career'] == '1'): ?> selected <?php endif; ?>>เจ้าของธุรกิจที่มีลูกจ้าง</option>
                            <option value="2" <?php if(isset($data['additional_career']) && $data['additional_career'] == '2'): ?> selected <?php endif; ?>>เจ้าของธุรกิจที่ไม่มีลูกจ้าง หรือ อาชีพอิสระ</option>
                            <option value="3" <?php if(isset($data['additional_career']) && $data['additional_career'] == '3'): ?> selected <?php endif; ?>>รวมกลุ่มกันเพื่อผลิตสินค้า/บริการ</option>
                            <option value="4" <?php if(isset($data['additional_career']) && $data['additional_career'] == '4'): ?> selected <?php endif; ?>>ผู้ช่วยธุรกิจในครัวเรือน (ไม่ได้รับค่าจ้าง)</option>
                            <option value="5" <?php if(isset($data['additional_career']) && $data['additional_career'] == '5'): ?> selected <?php endif; ?>>ข้าราชการบำนาญ</option>
                            <option value="6" <?php if(isset($data['additional_career']) && $data['additional_career'] == '6'): ?> selected <?php endif; ?>>นักการเมือง</option>
                            <option value="7" <?php if(isset($data['additional_career']) && $data['additional_career'] == '7'): ?> selected <?php endif; ?>>อัยการ/ตุลาการ/ผู้พิพากษา</option>
                            <option value="8" <?php if(isset($data['additional_career']) && $data['additional_career'] == '8'): ?> selected <?php endif; ?>>นักกฎหมายและผู้ใช้วิชาชีพทางกฎหมาย</option>
                            <option value="9" <?php if(isset($data['additional_career']) && $data['additional_career'] == '9'): ?> selected <?php endif; ?>>ทหาร/ตำรวจ</option>
                            <option value="10" <?php if(isset($data['additional_career']) && $data['additional_career'] == '10'): ?> selected <?php endif; ?>>ครู อาจารย์ และผู้ประกอบอาชีพการศึกษา (ยกเว้นติวเตอร์)</option>
                            <option value="11" <?php if(isset($data['additional_career']) && $data['additional_career'] == '11'): ?> selected <?php endif; ?>>แพทย์</option>
                            <option value="12" <?php if(isset($data['additional_career']) && $data['additional_career'] == '12'): ?> selected <?php endif; ?>>พยาบาล และผู้ประกอบการอาชีพที่เกี่ยวกับการแพทย์</option>
                            <option value="13" <?php if(isset($data['additional_career']) && $data['additional_career'] == '13'): ?> selected <?php endif; ?>>ข้าราชการอื่นๆ (ที่ไม่ใช่ข้อก่อนหน้า)</option>
                            <option value="14" <?php if(isset($data['additional_career']) && $data['additional_career'] == '14'): ?> selected <?php endif; ?>>วิศวกร/สถาปนิก</option>
                            <option value="15" <?php if(isset($data['additional_career']) && $data['additional_career'] == '15'): ?> selected <?php endif; ?>>นักบิน/ผู้ช่วยนักบิน/แอร์โฮสเตส/สจ๊วต</option>
                            <option value="16" <?php if(isset($data['additional_career']) && $data['additional_career'] == '16'): ?> selected <?php endif; ?>>พนักงานประจำ , พนักงานรัฐวิสาหกิจ</option>
                            <option value="17" <?php if(isset($data['additional_career']) && $data['additional_career'] == '17'): ?> selected <?php endif; ?>>ลูกจ้างชั่วคราว , พนักงานสัญญาจ้าง</option>
                            <option value="18" <?php if(isset($data['additional_career']) && $data['additional_career'] == '18'): ?> selected <?php endif; ?>>บุคคลในวงการบันเทิง</option>
                            <option value="19" <?php if(isset($data['additional_career']) && $data['additional_career'] == '19'): ?> selected <?php endif; ?>>บุคคลในวงการกีฬา</option>
                            <option value="20" <?php if(isset($data['additional_career']) && $data['additional_career'] == '20'): ?> selected <?php endif; ?>>ผู้เกษียณที่ไม่ได้รับบำนาญ</option>
                            <option value="21" <?php if(isset($data['additional_career']) && $data['additional_career'] == '21'): ?> selected <?php endif; ?>>อื่นๆ </option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="additional_career_income_per_month">รายได้เสริมรวมต่อเดือน (ถ้ามี)</label>
                        <div id="additional_career_income_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="additional_career_income_per_month" <?php if(isset($data['faculty'])): ?> value="<?php echo e($data['faculty']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="number_institutions">จำนวนสถาบันทั้งหมดที่ปัจจุบันท่านกู้อยู่</label>
                        <select id="number_institutions" class="w-full" name="number_institutions">
                            <option value="0" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '0'): ?> selected <?php endif; ?>>0</option>
                            <option value="1" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '1'): ?> selected <?php endif; ?>>1</option>
                            <option value="2" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '2'): ?> selected <?php endif; ?>>2</option>
                            <option value="3" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '3'): ?> selected <?php endif; ?>>3</option>
                            <option value="4" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '4'): ?> selected <?php endif; ?>>4</option>
                            <option value="5" <?php if(isset($data['number_institutions']) && $data['number_institutions'] == '5'): ?> selected <?php endif; ?>>5</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="debt_burden_per_month">ภาระหนี้สินรวมต่อเดือน</label>
                        <div id="debt_burden_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="debt_burden_per_month" <?php if(isset($data['debt_burden_per_month'])): ?> value="<?php echo e($data['debt_burden_per_month']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="marital_status">สถานภาพสมรส</label>
                        <select id="marital_status" class="w-full" name="marital_status">
                            <option value="หย่า,หม่าย" <?php if(isset($data['marital_status']) && $data['marital_status'] == 'หย่า,หม่าย'): ?> selected <?php endif; ?>>หย่า,หม่าย</option>
                            <option value="โสด" <?php if(isset($data['marital_status']) && $data['marital_status'] == 'โสด'): ?> selected <?php endif; ?>>โสด</option>
                            <option value="สมรสจดทะเบียน" <?php if(isset($data['marital_status']) && $data['marital_status'] == 'สมรสจดทะเบียน'): ?> selected <?php endif; ?>>สมรสจดทะเบียน</option>
                            <option value="สมรสไม่จดทะเบียน" <?php if(isset($data['marital_status']) && $data['marital_status'] == 'สมรสไม่จดทะเบียน'): ?> selected <?php endif; ?>>สมรสไม่จดทะเบียน</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="person_under_patronage">จำนวนบุตร / บุคคลภายใต้การอุปการะ เช่น บิดา มารดา คู่สมรส เป็นต้น</label>
                        <select id="person_under_patronage" class="w-full" name="person_under_patronage">
                            <option value="0" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '0'): ?> selected <?php endif; ?>>0</option>
                            <option value="1" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '1'): ?> selected <?php endif; ?>>1</option>
                            <option value="2" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '2'): ?> selected <?php endif; ?>>2</option>
                            <option value="3" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '3'): ?> selected <?php endif; ?>>3</option>
                            <option value="4" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '4'): ?> selected <?php endif; ?>>4</option>
                            <option value="5" <?php if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '5'): ?> selected <?php endif; ?>>5</option>
                        </select>
                    </div>


                    

                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-form4')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
                    </div>


                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form5.blade.php ENDPATH**/ ?>