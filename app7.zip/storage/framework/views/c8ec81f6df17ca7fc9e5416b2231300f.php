<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">กรอกและยืนยันเบอร์มือถือ</h1>
                <form class="education-form" action="<?php echo e(route('loan-form2submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">1.กรุณากรอกเบอร์มือถือ</div>
                        <div class="text-center"><input type="tel" id="telephone" name="telephone" class="block mx-auto w-[250px] border-gray-200 rounded-md" pattern="[0-9]{10}" <?php if(isset($data['telephone'])): ?> value="<?php echo e($data['telephone']); ?>" <?php endif; ?> required /></div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg" name="send-tel-otp" type="button" id="sendTelOtpBtn"  <?php if(isset($data['send-tel-otp'])): ?> value="<?php echo e($data['send-tel-otp']); ?>" <?php endif; ?>>ขอ OTP</button>
                        </div>
                    </div>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">2.กรุณากรอกยืนยัน SMS OTP</div>
                        <div class="flex justify-center space-x-3" data-hs-pin-input>
                            <div class="text-center"><input type="text" id="telOtp" name="tel-otp" class="block mx-auto w-[150px] border-gray-200 rounded-md" required /></div>
                        </div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg" type="button" id="verifyTelOtpBtn">ยืนยัน</button>
                        </div>
                    </div>


                    <h2 class="text-2xl font-medium text-educationColor text-center mb-0 text-[#ef3026]">กรอกและยืนยันอีเมล</h2>
                    <h3 class="text-lg font-medium text-educationColor text-center -mt-3 mb-5 text-[#ef3026]">สำหรับรับสัญญาเงินกู้และตารางการผ่อนชำระ</h3>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">1.กรุณากรอกอีเมลของท่าน</div>
                        <div class="text-center"><input type="email" id="email" name="email" class="block mx-auto w-[250px] border-gray-200 rounded-md" <?php if(isset($data['email'])): ?> value="<?php echo e($data['email']); ?>" <?php endif; ?> required></div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg" type="button" id="sendEmailOtpBtn">ขอ OTP</button>
                        </div>
                    </div>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">2.กรุณากรอกยืนยัน OTP ที่ท่านได้รับทางอีเมล</div>
                        <div class="flex justify-center space-x-3" data-hs-pin-input>
                            <div class="text-center"><input type="text" name="email-otp" class="block mx-auto w-[150px] border-gray-200 rounded-md" required /></div>
                        </div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg">ยืนยัน</button>
                        </div>
                    </div>


                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-form1')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
                    </div>
                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.7/dist/sweetalert2.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
        <script src="<?php echo e(asset('js/pin-input.js')); ?>"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function(){

                $('#sendTelOtpBtn').click(function(){
                    var telephone = $('#telephone').val();
                    $.ajax({
                        url: "<?php echo e(route('send_otp')); ?>",
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'telephone': telephone
                        },
                        success: function(response){
                            console.log(response);

                            Swal.fire({
                                title: "ส่ง OTP ไปที่เบอร์โทรศัพท์ของท่านแล้ว",
                                icon: "success"
                            });

                            $('#sendTelOtpBtn').attr('disabled', true).addClass('disabled');

                            $('#otpForm').hide();
                            $('#otpVerification').show();
                        },
                        error: function(xhr, status, error){
                            console.error(xhr.responseText);
                            alert('Failed to send OTP!');
                        }
                    });
                });

                $('#verifyTelOtpBtn').click(function(){
                    let phone_otp = $('#telOtp').val();
                    $.ajax({
                        url: "<?php echo e(route('verify_otp')); ?>",
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'phone_otp': phone_otp
                        },
                        success: function(response){
                            // console.log(response);
                            // $('#otpResult').html('<p>' + response.message + '</p>').show();
                            document.getElementById('telOtp').type = 'password';
                            Swal.fire({
                                title: "ยืนยันเบอร์โทรศัพท์สำเร็จ",
                                icon: "success"
                            });
                            $('#verifyTelOtpBtn').attr('disabled', true).addClass('disabled');
                        },
                        error: function(xhr, status, error){
                            // console.error(xhr.responseText);
                            // alert('Failed to verify OTP!');
                            $('#telOtp').val('');
                            Swal.fire({
                                title: "รหัส OTP ไม่ถูกต้อง",
                                icon: "warning"
                            });
                        }
                    });
                });

                $('#sendEmailOtpBtn').click(function(){
                    var email = $('#email').val();
                    $.ajax({
                        url: "<?php echo e(route('send_email_otp')); ?>",
                        type: 'POST',
                        dataType: 'json',
                        data: {
                            '_token': '<?php echo e(csrf_token()); ?>',
                            'email': email
                        },
                        success: function(response){
                            console.log(response);
                            $('#otpForm').hide();
                            $('#otpVerification').show();
                        },
                        error: function(xhr, status, error){
                            console.error(xhr.responseText);
                            alert('Failed to send OTP!');
                        }
                    });
                });

            });
        </script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form2.blade.php ENDPATH**/ ?>