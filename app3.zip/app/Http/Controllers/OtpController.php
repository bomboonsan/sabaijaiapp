<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class OtpController extends Controller
{
    public function sendOTP(Request $request)
    {
        $telephone = $request->input('telephone');

        // สุ่มค่า OTP
        $otp = mt_rand(100000, 999999);

        // เก็บค่า OTP ใน Session
        $request->session()->put('phone_otp', $otp);

        // // ส่ง OTP ไปยังหมายเลขโทรศัพท์ที่ระบุ

        $data = [
            "sender" => "SBJLifestyl",
            "msisdn" => [$telephone],
            "message" => 'OTP: ' . $otp, // นำค่า OTP ที่สุ่มได้มาใช้
        ];

        $response = Http::withToken('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC90aHNtcy5jb21cL2xvZ2luIiwiaWF0IjoxNjkxMzI3Njk1LCJuYmYiOjE2OTEzMjc2OTUsImp0aSI6IjFnUmE1VmY5NlZ1MVlWeEoiLCJzdWIiOjExMDE1NiwicHJ2IjoiMjNiZDVjODk0OWY2MDBhZGIzOWU3MDFjNDAwODcyZGI3YTU5NzZmNyJ9.9Hr3DbbxwbEvGQIApdj-VYE5UfFqNed0bDf2j1YhnJg')->post(
            'https://thsms.com/api/send-sms', $data
        );



        return $response->json();
    }

    public function verifyOTP(Request $request)
    {
        $userOTP = $request->input('phone_otp');

        // ดึงค่า OTP ที่เก็บไว้ใน Session
        $sessionOTP = $request->session()->get('phone_otp');

        if ($userOTP == $sessionOTP) {
            // OTP ถูกต้อง
            // ทำสิ่งที่คุณต้องการ เช่น ลงทะเบียนผู้ใช้หรือเข้าสู่ระบบ
            $request->session()->put('comfirm_phone', 'true');
            return response()->json(['message' => 'OTP ถูกต้อง']);
        } else {
            // OTP ไม่ถูกต้อง
            return response()->json(['message' => 'OTP ไม่ถูกต้อง'], 422);
        }
    }
}
