<div class="py-12">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/components/layouts/apply.blade.php ENDPATH**/ ?>