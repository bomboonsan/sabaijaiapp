<div class="app_wrapper">
    <main class="frontLayout">
        {{ $slot }}
    </main>
</div>
