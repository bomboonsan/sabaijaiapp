
<img class="w-[35px] md:w-[60px]" src="<?php echo e(asset('images/logoSBJWhite.png')); ?>" alt="">
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/components/application-mark.blade.php ENDPATH**/ ?>