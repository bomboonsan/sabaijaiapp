<div class="">
    <div class="bg-[#ef3026] py-2">
        <div class="max-w-screen-md mx-auto px-3">
            <div class="flex items-center justify-between gap-2">
                <div class="">
                    <img class="w-[65px] md:w-[80px]" src="<?php echo e(asset('images/logoSBJWhite.png')); ?>" alt="">
                </div>
                <div class="text-white">
                    <p>
                        <?php echo $__env->yieldContent('apply_id'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="max-w-screen-md mx-auto px-3 py-10">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/components/layouts/applyloan.blade.php ENDPATH**/ ?>