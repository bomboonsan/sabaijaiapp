<?php $__env->startSection('apply_id', $data['apply_id'] ?? ''); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    กรอกข้อมูลด้านอาชีพหลัก
                </h1>
                <form class="education-form" action="<?php echo e(route('loan-form6submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>


                    <div>
                        <label htmlFor="source_income">แหล่งที่มาของรายได้</label>
                        <div id="source_income" class="flex gap-3">
                            <input class="flex-1" type="text" name="source_income" <?php if(isset($data['source_income'])): ?> value="<?php echo e($data['source_income']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="pay_date">วันที่ต้องการชำระค่างวด</label>
                        <select id="pay_date" class="w-full" name="pay_date">
                            <?php for($i = 1; $i <= 31; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php if(isset($data['pay_date']) && $data['pay_date'] == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <h2 class="text-2xl font-medium text-educationColor text-center mb-0 text-[#ef3026]">ที่ทำงานของอาชีพหลัก</h2>

                    <div>
                        <label htmlFor="district_work">แขวง/ตำบล</label>
                        <div class="flex gap-3">
                            <input id="district_work" class="flex-1 w-full" type="text" name="district_work" <?php if(isset($data['district_work'])): ?> value="<?php echo e($data['district_work']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="amphoe_work">เขต/อำเภอ</label>
                        <div class="flex gap-3">
                            <input id="amphoe_work" class="flex-1 w-full" type="text" name="amphoe_work" <?php if(isset($data['amphoe_work'])): ?> value="<?php echo e($data['amphoe_work']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <div class="flex-1">
                            <label htmlFor="province_work">จังหวัด</label>
                            <input id="province_work" class="flex-1 w-full" type="text" name="province_work" <?php if(isset($data['province_work'])): ?> value="<?php echo e($data['province_work']); ?>" <?php endif; ?> />
                        </div>
                        <div class="flex-1">
                            <label htmlFor="zipcode_work">รหัสไปรษณีย์</label>
                            <input id="zipcode_work" class="flex-1 w-full" type="text" name="zipcode_work" <?php if(isset($data['zipcode_work'])): ?> value="<?php echo e($data['zipcode_work']); ?>" <?php endif; ?> />
                        </div>
                    </div>



                    

                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-form5')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ยืนยัน</button>
                    </div>


                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>

        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dependencies/typeahead.bundle.js"></script>
        <script type="text/javascript" src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dependencies/JQL.min.js"></script>
        <link rel="stylesheet" href="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dist/jquery.Thailand.min.css">
        <script type="text/javascript" src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dist/jquery.Thailand.min.js"></script>
        <script>
            $.Thailand({
                $district: $('#district_work'), // input ของตำบล
                $amphoe: $('#amphoe_work'), // input ของอำเภอ
                $province: $('#province_work'), // input ของจังหวัด
                $zipcode: $('#zipcode_work'), // input ของรหัสไปรษณีย์
            });
        </script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form6-type2.blade.php ENDPATH**/ ?>