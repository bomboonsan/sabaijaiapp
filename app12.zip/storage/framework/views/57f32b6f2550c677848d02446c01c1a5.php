<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body class="">
        <?php if (isset($component)) { $__componentOriginal3646e0bf888b1fb51c7a106aca338220 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3646e0bf888b1fb51c7a106aca338220 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.confirm','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.confirm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <img class="logo" src="<?php echo e(asset('images/logo.webp')); ?>" alt="sabaijai logo" />
            <p class="text-center text-3xl uppercase mb-3">บริษัท สบายใจมันนี่ จำกัด</p>
            <p class="text-center  md:text-lg">
                34 อาคาร B ชั้น 2 ห้องเลขที่ B204 <br/>
                อาคารซี.พี. ทาวเวอร์ 3 พญาไท กรุงเทพ 10400 <br/>
                โทรศัพท์: 0994523532
            </p>
            <hr class="my-5" />
            <p class="text-center text-lg">
                กรุณากรอกเลขบัตรประชาชน 13 หลัก เพื่อยืนยันเข้าระบบ
            </p>
            <form action="<?php echo e(route('confirm-verifyCitizen')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="input-citizenid" type="text" placeholder="XXXXXXXXXXXX" name="citizen_id" />

                <div class="text-center mt-20">
                    <button class="btn-submit" type="submit">ยืนยัน</button>
                    <?php if(session('error')): ?>
                        <p class="text-red-500"><?php echo e(session('error')); ?></p>
                    <?php endif; ?>
                </div>
            </form>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3646e0bf888b1fb51c7a106aca338220)): ?>
<?php $attributes = $__attributesOriginal3646e0bf888b1fb51c7a106aca338220; ?>
<?php unset($__attributesOriginal3646e0bf888b1fb51c7a106aca338220); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3646e0bf888b1fb51c7a106aca338220)): ?>
<?php $component = $__componentOriginal3646e0bf888b1fb51c7a106aca338220; ?>
<?php unset($__componentOriginal3646e0bf888b1fb51c7a106aca338220); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/confirm/index.blade.php ENDPATH**/ ?>