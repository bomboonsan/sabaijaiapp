<?php $__env->startSection('apply_id', $data['apply_id'] ?? ''); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-0 text-[#ef3026]">
                    กรอกข้อมูลบุคคลอ้างอิง
                </h1>
                <h2 class="text-lg font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    เป็นบุคคลที่สามารถติดต่อได้ (เฉพาะญาติเท่านั้น)
                </h2>
                <form class="education-form" action="<?php echo e(route('loan-form7submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label htmlFor="reference_name">ชื่อ - นามสกุล</label>
                        <div id="reference_name" class="flex gap-3">
                            <input class="flex-1" type="text" name="reference_name"  <?php if(isset($data['reference_name'])): ?> value="<?php echo e($data['reference_name']); ?>" <?php endif; ?> />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="reference_type">ความสัมพันธ์</label>
                        <select id="reference_type" class="w-full" name="reference_type">
                            <option value="บิดา" <?php if(isset($data['reference_type']) && $data['reference_type'] == '0'): ?> selected <?php endif; ?>>บิดา</option>
                            <option value="มารดา" <?php if(isset($data['reference_type']) && $data['reference_type'] == '1'): ?> selected <?php endif; ?>>มารดา</option>
                            <option value="พี่น้อง" <?php if(isset($data['reference_type']) && $data['reference_type'] == '2'): ?> selected <?php endif; ?>>พี่น้อง</option>
                            <option value="คู่สมรส" <?php if(isset($data['reference_type']) && $data['reference_type'] == '3'): ?> selected <?php endif; ?>>คู่สมรส</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="reference_tel">เบอร์มือถือ</label>
                        <div id="reference_tel" class="flex gap-3">
                            <input class="flex-1" type="tel" name="reference_tel" <?php if(isset($data['reference_tel'])): ?> value="<?php echo e($data['reference_tel']); ?>" <?php endif; ?> />
                        </div>
                    </div>


                    

                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-form6')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ยืนยัน</button>
                    </div>


                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form7.blade.php ENDPATH**/ ?>