<?php $__env->startSection('apply_id', $data['apply_id'] ?? ''); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">กรอกข้อมูลการศึกษาที่ต้องการจะขอสินเชื่อ</h1>
                <ul class="text-educationColor text-lg list-disc pl-5 mb-5 text-[#ef3026]">
                    <li>กู้ได้เฉพาะค่าเล่าเรียนของนิสิต/นักศึกษาที่ลงทะเบียนเรียนกับ มหาวิทยาลัยราชพฤกษ์เท่านั้น</li>
                    <li>กู้สำหรับค่าเล่าเรียนตลอดหลักสูตร โดยผู้กู้สามารถแจ้งยกเลิกได้ หากไม่ต้องการกู้ในภาคการศึกษาถัด ๆ ไป แต่ไม่สามารถยกเลิกระหว่างภาคการศึกษาได้</li>
                </ul>
                <form class="education-form" action="<?php echo e(route('loan-form1submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label htmlFor="name">ชื่อ-นามสกุล ของนิสิต/นักศึกษา</label>
                        <div id="name" class="flex gap-3">
                            <select name="gender">
                                <option value="นาย" <?php if(isset($data['gender']) && $data['gender'] == 'นาย'): ?> selected <?php endif; ?>>นาย</option>
                                <option value="นาง" <?php if(isset($data['gender']) && $data['gender'] == 'นาง'): ?> selected <?php endif; ?>>นาง</option>
                                <option value="นางสาว" <?php if(isset($data['gender']) && $data['gender'] == 'นางสาว'): ?> selected <?php endif; ?>>นางสาว</option>
                            </select>
                            <input class="flex-1" type="text" name="first_name" placeholder="ชื่อ" <?php if(isset($data['first_name'])): ?> value="<?php echo e($data['first_name']); ?>" <?php endif; ?> required />
                            <input class="flex-1" type="text" name="last_name" placeholder="นามสกุล" <?php if(isset($data['last_name'])): ?> value="<?php echo e($data['last_name']); ?>" <?php endif; ?> required />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="id_card">เลขบัตรประจำตัวประชาชน ของนิสิต/นักศึกษา</label>
                        <div id="id_card" class="flex gap-3">
                            <input class="flex-1" type="number" name="id_card" name="id_card" placeholder="xxxxxxxxx" <?php if(isset($data['id_card'])): ?> value="<?php echo e($data['id_card']); ?>" <?php endif; ?> />
                        </div>
                    </div>


                    <div class="flex gap-3">
                        <div class="flex-1">
                            <label htmlFor="education_level">ระดับชั้นการศึกษา </label>
                            <select id="education_level" class="w-full" name="education_level" required>
                                <option value="">เลือก</option>
                                <option value="ประกาศนียบัตรบัณฑิต" <?php if(isset($data['education_level']) && $data['education_level'] == 'ประกาศนียบัตรบัณฑิต'): ?> selected <?php endif; ?>>ประกาศนียบัตรบัณฑิต</option>
                                <option value="ปริญญาโท" <?php if(isset($data['education_level']) && $data['education_level'] == 'ปริญญาโท'): ?> selected <?php endif; ?>>ปริญญาโท</option>
                                <option value="ปริญญาเอก" <?php if(isset($data['education_level']) && $data['education_level'] == 'ปริญญาเอก'): ?> selected <?php endif; ?>>ปริญญาเอก</option>
                            </select>
                        </div>
                        <div class="flex-1">
                            <label htmlFor="education_lavel_year">ชั้นปีที่เริ่มกู้ </label>
                            <select id="education_lavel_year" class="w-full" name="education_lavel_year">
                                <option value="">เลือก</option>
                                <option value="1" <?php if(isset($data['education_lavel_year']) && $data['education_lavel_year'] == '1'): ?> selected <?php endif; ?>>1</option>
                                <option value="2" <?php if(isset($data['education_lavel_year']) && $data['education_lavel_year'] == '2'): ?> selected <?php endif; ?>>2</option>
                                <option value="3" <?php if(isset($data['education_lavel_year']) && $data['education_lavel_year'] == '3'): ?> selected <?php endif; ?>>3</option>
                                <option value="4" <?php if(isset($data['education_lavel_year']) && $data['education_lavel_year'] == '4'): ?> selected <?php endif; ?>>4</option>
                            </select>
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <div class="flex-1">
                            <label htmlFor="education_sublevel">ภาคการศึกษาที่เริ่มกู้ </label>
                            <select id="education_sublevel" class="w-full" name="education_sublevel">
                                <option value="">เลือก</option>
                                <option value="ภาคเรียนที่1" <?php if(isset($data['education_sublevel']) && $data['education_sublevel'] == 'ภาคเรียนที่1'): ?> selected <?php endif; ?>>ภาคเรียนที่ 1</option>
                                <option value="ภาคเรียนที่2" <?php if(isset($data['education_sublevel']) && $data['education_sublevel'] == 'ภาคเรียนที่2'): ?> selected <?php endif; ?>>ภาคเรียนที่ 2</option>
                                <option value="ภาคฤดูร้อน" <?php if(isset($data['education_sublevel']) && $data['education_sublevel'] == 'ภาคฤดูร้อน'): ?> selected <?php endif; ?>>ภาคฤดูร้อน</option>
                            </select>
                        </div>
                        <div class="flex-1">
                            <label htmlFor="education_year">ปีการศึกษาที่เริ่มกู้ </label>
                            <select id="education_year" class="w-full" name="education_year">
                                <option value="">เลือก</option>
                                <option value="2567" <?php if(isset($data['education_year']) && $data['education_year'] == '2567'): ?> selected <?php endif; ?>>2567</option>
                                
                            </select>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="faculty">หลักสูตร</label>
                        <div id="faculty" class="flex gap-3">
                            
                            <select id="faculty" class="w-full" name="faculty">
                                <option value="">เลือก</option>
                                <option value="หลักสูตรประกาศนียบัตรบัณฑิตวิชาชีพครู" <?php if(isset($data['faculty']) && $data['faculty'] == 'หลักสูตรประกาศนียบัตรบัณฑิตวิชาชีพครู'): ?> selected <?php endif; ?>>หลักสูตรประกาศนียบัตรบัณฑิตวิชาชีพครู</option>
                                <option value="หลักสูตรบัญชีมหาบัณฑิต (M.Acc.) - คณะบัญชี" <?php if(isset($data['faculty']) && $data['faculty'] == 'หลักสูตรบัญชีมหาบัณฑิต (M.Acc.) - คณะบัญชี'): ?> selected <?php endif; ?>>หลักสูตรบัญชีมหาบัณฑิต (M.Acc.) - คณะบัญชี</option>
                                <option value="หลักสูตรบริหารธุรกิจมหาบัณฑิต (M.B.A.) - คณะบริหารธุรกิจ" <?php if(isset($data['faculty']) && $data['faculty'] == 'หลักสูตรบริหารธุรกิจมหาบัณฑิต (M.B.A.) - คณะบริหารธุรกิจ'): ?> selected <?php endif; ?>>หลักสูตรบริหารธุรกิจมหาบัณฑิต (M.B.A.) - คณะบริหารธุรกิจ</option>
                                <option value="หลักสูตรศึกษาศาสตรมหาบัณฑิต (M.Ed.) - คณะศิลปศาสตร์" <?php if(isset($data['faculty']) && $data['faculty'] == 'หลักสูตรศึกษาศาสตรมหาบัณฑิต (M.Ed.) - คณะศิลปศาสตร์'): ?> selected <?php endif; ?>>หลักสูตรศึกษาศาสตรมหาบัณฑิต (M.Ed.) - คณะศิลปศาสตร์</option>
                                <option value="หลักสูตรปรัชญาดุษฎีบัณฑิต (Ph.D.) - คณะศิลปศาสตร์" <?php if(isset($data['faculty']) && $data['faculty'] == 'หลักสูตรปรัชญาดุษฎีบัณฑิต (Ph.D.) - คณะศิลปศาสตร์'): ?> selected <?php endif; ?>>หลักสูตรปรัชญาดุษฎีบัณฑิต (Ph.D.) - คณะศิลปศาสตร์</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="university">ชื่อสถานศึกษา</label>
                        <div id="university" class="flex gap-3">
                            
                            <select id="university" class="w-full" name="university">
                                <option value="">เลือก</option>
                                <option value="มหาวิทยาลัยราชพฤกษ์" <?php if(isset($data['university']) && $data['university'] == 'มหาวิทยาลัยราชพฤกษ์'): ?> selected <?php endif; ?>>มหาวิทยาลัยราชพฤกษ์</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label htmlFor="amount">ค่าเล่าเรียนที่ต้องการกู้</label>
                        <div id="amount" class="flex gap-3">
                            <input class="flex-1" type="text" name="amount" <?php if(isset($data['amount'])): ?> value="<?php echo e($data['amount']); ?>" <?php endif; ?> />
                        </div>
                    </div>


                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-index')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button type="submit" class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ยืนยัน</button>
                    </div>
                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form1.blade.php ENDPATH**/ ?>