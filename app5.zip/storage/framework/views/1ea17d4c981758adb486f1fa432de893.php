<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body>

        <?php if (isset($component)) { $__componentOriginalca80a79cb189e712217440b0c69ec4ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca80a79cb189e712217440b0c69ec4ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.applyloan','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.applyloan'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    สรุปข้อมูลการขอสินเชื่อ
                </h1>
                <form class="education-form">

                    <div class="mb-1 flex justify-between items-center">
                        <div class="">
                            จำนวนเงินที่ขอสินเชื่อ
                        </div>
                        <div class="">
                            x บาท
                        </div>
                    </div>
                    <div class="mb-1 flex justify-between items-center">
                        <div class="">
                            ระยะเวลาผ่อน
                        </div>
                        <div class="">
                            x บาท
                        </div>
                    </div>
                    <div class="mb-1 flex justify-between items-center">
                        <div class="">
                            ยอดชำระ/เดือน
                        </div>
                        <div class="">
                            x บาท
                        </div>
                    </div>
                    <div class="mb-1 flex justify-between items-center">
                        <div class="">
                            วันที่กำหนดชำระ
                        </div>
                        <div class="">
                            x บาท
                        </div>
                    </div>

                    <p>
                        หากต้องการเปลี่ยนแปลงแก้ไขข้อมูลการขอสินเชื่อข้างต้น
                        ให้ กด ”กลับไป” เพื่อทำการแก้ไข
                    </p>

                    <div class="text-sm mt-10">
                        <p class="text-center">
                            **รายละเอียดข้างต้นเป็นการกู้ตลอดหลักสูตร อย่างไรก็ตามหากท่านไม่ประสงค์ที่จะต่อสัญญาฉบับถัดไป ท่านสามารถยกเลิกได้**
                        </p>
                    </div>

                    <div class="text-lg mt-10">
                        <p class="text-center">
                            โปรดแอดไลน์ เพื่อรับทราบผลการอนุมัติของท่าน
                        </p>
                    </div>

                    

                    <div class="flex justify-center items-center gap-5">
                        <a href="<?php echo e(route('loan-form4')); ?>" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งใบสมัครและแอดไลน์</button>
                    </div>


                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $attributes = $__attributesOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__attributesOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca80a79cb189e712217440b0c69ec4ac)): ?>
<?php $component = $__componentOriginalca80a79cb189e712217440b0c69ec4ac; ?>
<?php unset($__componentOriginalca80a79cb189e712217440b0c69ec4ac); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/applyloan/form9.blade.php ENDPATH**/ ?>