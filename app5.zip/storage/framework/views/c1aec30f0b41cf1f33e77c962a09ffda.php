<div class="app_wrapper">
    <main class="frontLayout">
        <?php echo e($slot); ?>

    </main>
</div>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/components/layouts/confirm.blade.php ENDPATH**/ ?>