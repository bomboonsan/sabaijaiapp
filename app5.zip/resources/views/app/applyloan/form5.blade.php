<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        @vite(['resources/scss/app.scss', 'resources/js/app.js'])
    </head>
    <body>

        <x-layouts.applyloan>
            <div class="p-5 md:p-10">
                <h1 class="text-2xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">
                    กรอกรายได้และค่าใช้จ่าย
                </h1>
                <form class="education-form" action="{{ route('loan-form5submit') }}" method="POST">
                    @csrf
                    <div>
                        <label htmlFor="main_occupation">อาชีพหลัก</label>
                        <select id="main_occupation" class="w-full" name="main_occupation">
                            <option value="อาชีพที่1" @if(isset($data['main_occupation']) && $data['main_occupation'] == 'อาชีพที่1') selected @endif>อาชีพที่ 1</option>
                            <option value="อาชีพที่2" @if(isset($data['main_occupation']) && $data['main_occupation'] == 'อาชีพที่2') selected @endif>อาชีพที่ 2</option>
                            <option value="อาชีพที่3" @if(isset($data['main_occupation']) && $data['main_occupation'] == 'อาชีพที่3') selected @endif>อาชีพที่ 3</option>
                            <option value="อาชีพที่4" @if(isset($data['main_occupation']) && $data['main_occupation'] == 'อาชีพที่4') selected @endif>อาชีพที่ 4</option>
                            <option value="อาชีพที่5" @if(isset($data['main_occupation']) && $data['main_occupation'] == 'อาชีพที่5') selected @endif>อาชีพที่ 5</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="nature_employment">ลักษณะการจ้างงาน</label>
                        <select id="nature_employment" class="w-full" name="nature_employment">
                            <option value="แบบที่1" @if(isset($data['nature_employment']) && $data['nature_employment'] == 'แบบที่1') selected @endif>แบบที่ 1</option>
                            <option value="แบบที่2" @if(isset($data['nature_employment']) && $data['nature_employment'] == 'แบบที่2') selected @endif>แบบที่ 2</option>
                            <option value="แบบที่3" @if(isset($data['nature_employment']) && $data['nature_employment'] == 'แบบที่3') selected @endif>แบบที่ 3</option>
                            <option value="แบบที่4" @if(isset($data['nature_employment']) && $data['nature_employment'] == 'แบบที่4') selected @endif>แบบที่ 4</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="type_business">ประเภทธุรกิจขององค์กรหรือหน่วยงานที่ทำงานอยู่</label>
                        <select id="type_business" class="w-full" name="type_business">
                            <option value="ประเภทธุรกิจ1" @if(isset($data['type_business']) && $data['type_business'] == 'ประเภทธุรกิจ1') selected @endif>ประเภทธุรกิจ 1</option>
                            <option value="ประเภทธุรกิจ2" @if(isset($data['type_business']) && $data['type_business'] == 'ประเภทธุรกิจ2') selected @endif>ประเภทธุรกิจ 2</option>
                            <option value="ประเภทธุรกิจ3" @if(isset($data['type_business']) && $data['type_business'] == 'ประเภทธุรกิจ3') selected @endif>ประเภทธุรกิจ 3</option>
                            <option value="ประเภทธุรกิจ4" @if(isset($data['type_business']) && $data['type_business'] == 'ประเภทธุรกิจ4') selected @endif>ประเภทธุรกิจ 4</option>
                            <option value="ประเภทธุรกิจ5" @if(isset($data['type_business']) && $data['type_business'] == 'ประเภทธุรกิจ5') selected @endif>ประเภทธุรกิจ 5</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="main_income_per_month">รายได้หลักรวมต่อเดือน</label>
                        <div id="main_income_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="main_income_per_month" value="{{ isset($data['main_income_per_month']) ? $data['main_income_per_month'] : '' }}" />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="additional_career">อาชีพเสริม (ถ้ามี)</label>
                        <select id="additional_career" class="w-full" name="additional_career">
                            <option value="ประเภทธุรกิจ1" @if(isset($data['additional_career']) && $data['additional_career'] == 'ประเภทธุรกิจ1') selected @endif>ประเภทธุรกิจ 1</option>
                            <option value="ประเภทธุรกิจ2" @if(isset($data['additional_career']) && $data['additional_career'] == 'ประเภทธุรกิจ2') selected @endif>ประเภทธุรกิจ 2</option>
                            <option value="ประเภทธุรกิจ3" @if(isset($data['additional_career']) && $data['additional_career'] == 'ประเภทธุรกิจ3') selected @endif>ประเภทธุรกิจ 3</option>
                            <option value="ประเภทธุรกิจ4" @if(isset($data['additional_career']) && $data['additional_career'] == 'ประเภทธุรกิจ4') selected @endif>ประเภทธุรกิจ 4</option>
                            <option value="ประเภทธุรกิจ5" @if(isset($data['additional_career']) && $data['additional_career'] == 'ประเภทธุรกิจ5') selected @endif>ประเภทธุรกิจ 5</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="additional_career_income_per_month">รายได้เสริมรวมต่อเดือน (ถ้ามี)</label>
                        <div id="additional_career_income_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="additional_career_income_per_month" @if(isset($data['faculty'])) value="{{ $data['faculty'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="number_institutions">จำนวนสถาบันทั้งหมดที่ปัจจุบันท่านกู้อยู่</label>
                        <select id="number_institutions" class="w-full" name="number_institutions">
                            <option value="0" @if(isset($data['number_institutions']) && $data['number_institutions'] == '0') selected @endif>0</option>
                            <option value="1" @if(isset($data['number_institutions']) && $data['number_institutions'] == '1') selected @endif>1</option>
                            <option value="2" @if(isset($data['number_institutions']) && $data['number_institutions'] == '2') selected @endif>2</option>
                            <option value="3" @if(isset($data['number_institutions']) && $data['number_institutions'] == '3') selected @endif>3</option>
                            <option value="4" @if(isset($data['number_institutions']) && $data['number_institutions'] == '4') selected @endif>4</option>
                            <option value="5" @if(isset($data['number_institutions']) && $data['number_institutions'] == '5') selected @endif>5</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="debt_burden_per_month">ภาระหนี้สินรวมต่อเดือน</label>
                        <div id="debt_burden_per_month" class="flex gap-3">
                            <input class="flex-1" type="number" name="debt_burden_per_month" @if(isset($data['debt_burden_per_month'])) value="{{ $data['debt_burden_per_month'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="marital_status">สถานภาพสมรส</label>
                        <select id="marital_status" class="w-full" name="marital_status">
                            <option value="โสด" @if(isset($data['marital_status']) && $data['marital_status'] == 'โสด') selected @endif>โสด</option>
                            <option value="สมรส" @if(isset($data['marital_status']) && $data['marital_status'] == 'สมรส') selected @endif>สมรส</option>
                            <option value="หย่าร้าง" @if(isset($data['marital_status']) && $data['marital_status'] == 'หย่าร้าง') selected @endif>หย่าร้าง</option>
                        </select>
                    </div>

                    <div>
                        <label htmlFor="person_under_patronage">จำนวนบุตร / บุคคลภายใต้การอุปการะ เช่น บิดา มารดา คู่สมรส เป็นต้น</label>
                        <select id="person_under_patronage" class="w-full" name="person_under_patronage">
                            <option value="0" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '0') selected @endif>0</option>
                            <option value="1" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '1') selected @endif>1</option>
                            <option value="2" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '2') selected @endif>2</option>
                            <option value="3" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '3') selected @endif>3</option>
                            <option value="4" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '4') selected @endif>4</option>
                            <option value="5" @if(isset($data['person_under_patronage']) && $data['person_under_patronage'] == '5') selected @endif>5</option>
                        </select>
                    </div>


                    {{-- SUBMIT --}}

                    <div class="flex justify-center items-center gap-5">
                        <a href="{{ route('loan-form4') }}" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
                    </div>


                </form>
            </div>
        </x-layouts.applyloan>
        <script src="{{ asset('js/preline.js') }}"></script>
    </body>
</html>
