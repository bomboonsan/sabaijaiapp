<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        @vite(['resources/scss/app.scss', 'resources/js/app.js'])
    </head>
    <body>

        <x-layouts.applyloan>
            <div class="p-5 md:p-10">
                <h1 class="text-3xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">กรอกข้อมูลการศึกษาที่ต้องการจะขอสินเชื่อ</h1>
                <ul class="text-educationColor text-lg list-disc pl-5 mb-5 text-[#ef3026]">
                    <li>กู้ได้เฉพาะค่าเล่าเรียนของนิสิต/นักศึกษาที่ลงทะเบียนเรียนกับ มหาวิทยาลัยราชพฤกษ์เท่านั้น</li>
                    <li>กู้สำหรับค่าเล่าเรียนตลอดหลักสูตร โดยผู้กู้สามารถแจ้งยกเลิกได้ หากไม่ต้องการกู้ในภาคการศึกษาถัด ๆ ไป แต่ไม่สามารถยกเลิกระหว่างภาคการศึกษาได้</li>
                </ul>
                <form class="education-form" action="{{ route('loan-form1submit') }}" method="POST">
                    @csrf
                    <div>
                        <label htmlFor="name">ชื่อ-นามสกุล ของนิสิต/นักศึกษา</label>
                        <div id="name" class="flex gap-3">
                            <select name="gender">
                                <option value="นาย">นาย</option>
                                <option value="นาง">นาง</option>
                                <option value="นางสาว">นางสาว</option>
                            </select>
                            <input class="flex-1" type="text" name="firstname" placeholder="ชื่อ" @if(isset($data['firstname'])) value="{{ $data['firstname'] }}" @endif />
                            <input class="flex-1" type="text" name="lastname" placeholder="นามสกุล" @if(isset($data['lastname'])) value="{{ $data['lastname'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="id_card">เลขบัตรประจำตัวประชาชน ของนิสิต/นักศึกษา</label>
                        <div id="id_card" class="flex gap-3">
                            <input class="flex-1" type="number" name="id_card" name="id_card" placeholder="xxxxxxxxx" @if(isset($data['id_card'])) value="{{ $data['id_card'] }}" @endif />
                        </div>
                    </div>


                    <div class="flex gap-3">
                        <div class="flex-1">
                            <label htmlFor="level">ระดับชั้นการศึกษา </label>
                            <select id="level" class="w-full" name="level">
                                <option value="ม.6">ม.6</option>
                                <option value="ปวช">ปวช</option>
                                <option value="ปวส">ปวส</option>
                                <option value="อนุปริญญา">อนุปริญญา</option>
                                <option value="ปริญญาตรี">ปริญญาตรี</option>
                                <option value="ปริญญาโท">ปริญญาโท</option>
                                <option value="ปริญญาเอก">ปริญญาเอก</option>
                            </select>
                        </div>
                        <div class="flex-1">
                            <label htmlFor="year">ชั้นปีที่เริ่มกู้ </label>
                            <input class="w-full" type="text" name="year" @if(isset($data['year'])) value="{{ $data['year'] }}" @endif />
                        </div>
                    </div>

                    <div class="flex gap-3">
                        <div class="flex-1">
                            <label htmlFor="sublevel">ภาคการศึกษาที่เริ่มกู้ </label>
                            <select id="sublevel" class="w-full" name="sublevel">
                                <option value="ภาคเรียนที่ 1">ภาคเรียนที่ 1</option>
                                <option value="ภาคเรียนที่ 2">ภาคเรียนที่ 2</option>
                                <option value="ภาคเรียนที่ 3">ภาคเรียนที่ 3</option>
                            </select>
                        </div>
                        <div class="flex-1">
                            <label htmlFor="year">ปีการศึกษาที่เริ่มกู้ </label>
                            <input class="w-full" type="text" name="subyear" @if(isset($data['subyear'])) value="{{ $data['subyear'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="faculty">ชื่อคณะ</label>
                        <div id="faculty" class="flex gap-3">
                            <input class="flex-1" type="text" name="faculty" @if(isset($data['faculty'])) value="{{ $data['faculty'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="university">ชื่อสถานศึกษา</label>
                        <div id="university" class="flex gap-3">
                            <input class="flex-1" type="text" name="university" @if(isset($data['university'])) value="{{ $data['university'] }}" @endif />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="price">ค่าเล่าเรียนที่ต้องการกู้</label>
                        <div id="price" class="flex gap-3">
                            <input class="flex-1" type="text" name="price" @if(isset($data['price'])) value="{{ $data['price'] }}" @endif />
                        </div>
                    </div>


                    <div class="flex justify-center items-center gap-5">
                        <a href="{{ route('loan-index') }}" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button type="submit" class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
                    </div>
                </form>
            </div>
        </x-layouts.applyloan>
        <script src="{{ asset('js/preline.js') }}"></script>
    </body>
</html>
