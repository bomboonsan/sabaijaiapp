<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        @vite(['resources/scss/app.scss', 'resources/js/app.js'])
    </head>
    <body>

        <x-layouts.applyloan>
            <div class="p-5 md:p-10">
                <h1 class="text-3xl font-medium text-educationColor text-center mb-5 text-[#ef3026]">กรอกและยืนยันเบอร์มือถือ</h1>
                <form class="education-form">

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">1.กรุณากรอกเบอร์มือถือ</div>
                        <div class="flex justify-center space-x-3" data-hs-pin-input>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            {{--  --}}
                            <div class="px-1"></div>
                            {{--  --}}
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                        </div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg">ขอ OTP</button>
                        </div>
                    </div>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">2.กรุณากรอกยืนยัน SMS OTP</div>
                        <div class="flex justify-center space-x-3" data-hs-pin-input>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>

                        </div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg">ยืนยัน</button>
                        </div>
                    </div>


                    <h2 class="text-3xl font-medium text-educationColor text-center mb-0 text-[#ef3026]">กรอกและยืนยันอีเมล</h2>
                    <h3 class="text-lg font-medium text-educationColor text-center -mt-3 mb-5 text-[#ef3026]">สำหรับรับสัญญาเงินกู้และตารางการผ่อนชำระ</h3>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">1.กรุณากรอกอีเมลของท่าน</div>
                        <div class="text-center"><input type="email" class="block mx-auto w-[250px] border-gray-200 rounded-md"></div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg">ขอ OTP</button>
                        </div>
                    </div>

                    <div class="w-full mb-10">
                        <div class="text-center mb-1">2.กรุณากรอกยืนยัน OTP ที่ท่านได้รับทางอีเมล</div>
                        <div class="flex justify-center space-x-3" data-hs-pin-input>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>
                            <input type="text" class="flex-initial w-[32px] text-center border-gray-200 rounded-md text-sm [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none" data-hs-pin-input-item>

                        </div>
                        <div class="text-center mt-3">
                            <button class="bg-[#ef3026] text-white py-1 px-5 rounded-lg">ยืนยัน</button>
                        </div>
                    </div>


                    <div class="flex justify-center items-center gap-5">
                        <a href="{{ route('loan-form1') }}" class="bg-[#ef3026]/50 text-white py-3 px-5 rounded-lg">ย้อนกลับ</a>
                        <button class="bg-[#ef3026] text-white py-3 px-5 rounded-lg">ส่งข้อมูล</button>
                    </div>
                </form>
            </div>
        </x-layouts.applyloan>
        <script src="{{ asset('js/preline.js') }}"></script>
    </body>
</html>
