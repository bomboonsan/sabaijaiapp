<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>สบายใจมันนี่</title>
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/js/app.js']); ?>
    </head>
    <body class="">
        <?php if (isset($component)) { $__componentOriginal3646e0bf888b1fb51c7a106aca338220 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3646e0bf888b1fb51c7a106aca338220 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.confirm','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.confirm'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

            <div class="text-center">
            <img class="block mx-auto mb-10" src="<?php echo e(asset('images/checked.png')); ?>" alt="checked" />
            </div>
            <h1 class="text-center text-4xl uppercase mb-3">
            สำเร็จ !!!
            </h1>
            <p class="text-center text-2xl uppercase mb-3">
                ท่านสามารถดูสัญญาจากลิ้งค์<br/>
                ในไลน์ที่บริษัทจัดส่งให้
            </p>

            <div class="text-center mt-10 mb-5">
            <a href="https://lin.ee/wXcZnEG" target="_blank" class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#f21b10] hover:bg-red-600">
                กลับสู่หน้าไลน์
            </a>
            </div>

            <p class="text-center uppercase mb-3">
            โปรดสมัครสมาชิกในไลน์(สำหรับลูกค้าใหม่)<br/> เพื่อรับการแจ้งเตือนค่างวดและรับใบเสร็จการชำระ
            </p>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3646e0bf888b1fb51c7a106aca338220)): ?>
<?php $attributes = $__attributesOriginal3646e0bf888b1fb51c7a106aca338220; ?>
<?php unset($__attributesOriginal3646e0bf888b1fb51c7a106aca338220); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3646e0bf888b1fb51c7a106aca338220)): ?>
<?php $component = $__componentOriginal3646e0bf888b1fb51c7a106aca338220; ?>
<?php unset($__componentOriginal3646e0bf888b1fb51c7a106aca338220); ?>
<?php endif; ?>
        <script src="<?php echo e(asset('js/preline.js')); ?>"></script>
    </body>
</html>
<?php /**PATH /home/bomboonsan/Desktop/laravel/sabaijaiApp/resources/views/app/confirm/success.blade.php ENDPATH**/ ?>