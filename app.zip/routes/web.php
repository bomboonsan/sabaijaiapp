<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApplyLoanController;
use App\Http\Controllers\ConfirmController;

Route::get('/', function () {
    return view('welcome');
});


Route::get('/confirm', [ConfirmController::class, 'index'])->name('confirm-index');
Route::get('/confirm/select', [ConfirmController::class, 'select'])->name('confirm-select');
Route::get('/confirm/policy', [ConfirmController::class, 'policy'])->name('confirm-policy');
Route::get('/confirm/success', [ConfirmController::class, 'success'])->name('confirm-success');
Route::post('/verifyCitizen', [ConfirmController::class, 'verifyCitizen'])->name('confirm-verifyCitizen');
Route::post('/confirm/selected', [ConfirmController::class, 'policySelected'])->name('confirm-selected');
Route::post('/confirm/policy', [ConfirmController::class, 'policyConfirm'])->name('confirm-policyConfirm');

Route::get('/loan', [ApplyLoanController::class, 'index'])->name('loan-index');
Route::get('/loan/form1', [ApplyLoanController::class, 'form1'])->name('loan-form1');
Route::post('/loan/form1', [ApplyLoanController::class, 'form1submit'])->name('loan-form1submit');
Route::get('/loan/form2', [ApplyLoanController::class, 'form2'])->name('loan-form2');



Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});
