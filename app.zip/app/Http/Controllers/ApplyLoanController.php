<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ApplyLoanController extends Controller
{
    public function index()
    {
        return view('app.applyloan.index');
    }

    public function form1()
    {
        // Session::forget('form1');
        $data = Session::get('form1');
        if ($data) {
            return view('app.applyloan.form1', ['data' => $data]);
        } else {
            return view('app.applyloan.form1');
        }
    }
    public function form1Submit(Request $request)
    {
        $request->session()->put('form1', $request->all());
        return redirect()->route('loan-form2');
    }
    public function form2()
    {
        return view('app.applyloan.form2');
    }
}
