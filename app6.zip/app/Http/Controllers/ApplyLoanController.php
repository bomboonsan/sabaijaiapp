<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class ApplyLoanController extends Controller
{
    public function index()
    {
        return view('app.applyloan.index');
    }

    public function form1()
    {
        // Session::forget('form1');
        $data = Session::get('applyloan');
        if ($data) {
            return view('app.applyloan.form1', ['data' => $data]);
        } else {
            return view('app.applyloan.form1');
        }
    }
    public function form1Submit(Request $request)
    {
        $request->session()->put('applyloan', $request->all());
        return redirect()->route('loan-form2');
    }
    public function form2()
    {
        $data = Session::get('applyloan');
        Session::forget('comfirm_phone');

        if ($data) {
            return view('app.applyloan.form2', ['data' => $data]);
        } else {
            return view('app.applyloan.form2');
        }
    }

    public function formOtpemail()
    {
        $data = Session::get('applyloan');
        Session::forget('comfirm_phone');

        if ($data) {
            return view('app.applyloan.otpemail', ['data' => $data]);
        } else {
            return view('app.applyloan.otpemail');
        }
    }


    public function form2Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        $comfirm_phone = $request->session()->get('comfirm_phone');
        if($comfirm_phone != 'true'){
            return redirect()->route('loan-form2');
        }


        return redirect()->route('loan-form3');
    }
    public function form3()
    {
        $data = Session::get('applyloan');
        if(empty($data['firstname'])){
            return redirect()->route('loan-form1');
        }
        if ($data) {
            return view('app.applyloan.form3', ['data' => $data]);
        } else {
            return view('app.applyloan.form3');
        }
    }
    public function form3Submit(Request $request)
    {
        $dataSession = Session::get('applyloan');
        // dd($dataSession);

        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        // ************************************************
        // START KYC
        // ************************************************


        // APPMAN AUTH
        $response = Http::asForm()->post('https://mac-portal.appmanteam.com/auth/realms/mac-portal/protocol/openid-connect/token', [
            'grant_type' => 'client_credentials',
            'client_id' => 'sabaijaimoney-case-keeper-service-account',
            'client_secret' => 'a063eb0d-3395-4b01-a634-9c78f6756832',
        ]);
        $resultAuth = $response->json();
        $access_token = $resultAuth['access_token'];

        // APPMAN KYC

        $kycBody = [
            "caseType" => [
                "key" => "cc",
                "code" => "00899",
                "translations" => [
                    "en" => ["label" => "Criminal Check"],
                    "th" => ["label" => "Criminal Check"],
                    "id" => ["label" => "Criminal Check"]
                ]
            ],
            "proprietors" => [
                [
                    "expiryDuration" => "P30D",
                    "notifyDuration" => "P5D",
                    "proprietorType" => "insured",
                    // "citizenId" => "1-1999-00368-344",
                    "citizenId" => $dataSession['id_card'],
                    "firstName" => $dataSession['firstname'],
                    "lastName" => $dataSession['lastname'],
                    // "dateOfBirth" => "1993-10-30",
                    "notifyType" => "sms",
                    "phoneNumber" => $dataSession['telephone'],
                    "verifications" => [
                        [
                            "expiryDuration" => "P40D",
                            "notifyType" => "email",
                            "notifyInterval" => "P40D",
                            "frontIdCardConfig" => [
                                "required" => true,
                                "attempts" => 3,
                                "threshHold" => 0.1,
                                "dependenciesRequired" => false,
                                "isEditable" => false,
                                "validations" => ["comparison"]
                            ],
                            "passportConfig" => ["required" => true, "attempts" => 3, "threshHold" => 0.1, "dependenciesRequired" => false, "isEditable" => false],
                            "backIdCardConfig" => ["required" => true, "attempts" => 3, "threshHold" => 0.1, "dependenciesRequired" => false, "isEditable" => false],
                            "idFaceRecognitionConfig" => ["required" => true, "attempts" => 3, "threshHold" => 0.1, "dependenciesRequired" => false, "livenessCount" => 1],
                            "amloConfig" => ["required" => true],
                            "dopaConfig" => ["required" => true],
                            "dipChipConfig" => ["required" => true],
                            "bankruptcyConfig" => ["required" => true],
                            "sanctionConfig" => ["required" => true],
                            "criminalCheckConfig" => ["required" => true],
                            "employmentVerificationConfig" => ["required" => true]
                        ]
                    ]
                ]
            ],
            "remark" => null,
            "attachMeetingRoom" => false
        ];

        $response = Http::withToken($access_token)->post(
            'https://mac-portal.appmanteam.com/api/v2/case-keeper/cases', $kycBody
        );
        $resultKYC = $response->json();
        $KycID = $resultKYC['proprietors'][0]['verificationRef'];
        $fullUrlKyc = 'https://sabaijaimoney.mac.appmanteam.com/apps/identity-verification/'.$KycID.'?redirect=https://sabaijaiapp.bomboonsan.com/loan/form4';
        // dd($fullUrlKyc);
        return redirect($fullUrlKyc);

        // ************************************************
        // END KYC
        // ************************************************

        // return redirect()->route('loan-form4');
    }
    public function form4()
    {
        $data = Session::get('applyloan');
        if ($data) {
            return view('app.applyloan.form4', ['data' => $data]);
        } else {
            return view('app.applyloan.form4');
        }
    }
    public function form4Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        return redirect()->route('loan-form5');
    }
    public function form5()
    {
        $data = Session::get('applyloan');
        if ($data) {
            return view('app.applyloan.form5', ['data' => $data]);
        } else {
            return view('app.applyloan.form5');
        }
    }
    public function form5Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        return redirect()->route('loan-form6');
    }
    public function form6()
    {
        $data = Session::get('applyloan');
        $nature_employment = $data['nature_employment'];
        if ($nature_employment == 'แบบที่1') {
            return view('app.applyloan.form6-type1', ['data' => $data]);
        }
        if ($nature_employment == 'แบบที่2') {
            return view('app.applyloan.form6-type2', ['data' => $data]);
        }
        if ($nature_employment == 'แบบที่3') {
            return view('app.applyloan.form6-type3', ['data' => $data]);
        } else {
            return view('app.applyloan.form6-type4', ['data' => $data]);
        }


        // return view('app.applyloan.form6-type4');
    }
    public function form6Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        return redirect()->route('loan-form7');
    }
    public function form7()
    {
        $data = Session::get('applyloan');
        if ($data) {
            return view('app.applyloan.form7', ['data' => $data]);
        } else {
            return view('app.applyloan.form7');
        }
    }
    public function form7Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        return redirect()->route('loan-form8');
    }
    public function form8()
    {
        $data = Session::get('applyloan');
        if ($data) {
            return view('app.applyloan.form8', ['data' => $data]);
        } else {
            return view('app.applyloan.form8');
        }
    }
    public function form8Submit(Request $request)
    {
        // merge old data applyloan with request->all()
        $request->session()->put('applyloan', array_merge($request->session()->get('applyloan'), $request->all()));

        return redirect()->route('loan-form9');
    }
    public function form9()
    {
        return view('app.applyloan.form9');
    }
    public function form9Submit(Request $request)
    {
        return redirect()->route('loan-success');
    }
    public function success()
    {
        return view('app.applyloan.success');
    }
}
